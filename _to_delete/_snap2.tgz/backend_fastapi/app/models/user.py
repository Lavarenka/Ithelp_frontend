from datetime import datetime

from sqlalchemy import Integer, String, DateTime, Boolean, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from app.database import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    username: Mapped[str] = mapped_column(String(50), nullable=False, unique=True, index=True)
    email: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    # "admin" может создавать/редактировать статьи и теги, "user" — только читать.
    role: Mapped[str] = mapped_column(String(20), default="user", nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    # Подтверждение email — "мягкое": пока False, пользователь всё равно
    # может пользоваться сайтом (см. app/routers/auth.py), просто видит
    # баннер с предложением подтвердить и кнопкой повторной отправки письма.
    email_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    # Аватар хранится прямо в БД как data-URI (base64) — без отдельного файлового
    # хранилища. Пока показывается только на странице профиля (см. запрос
    # пользователя), по всему сайту подключим отдельной задачей позже.
    avatar: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    articles: Mapped[list["Article"]] = relationship("Article", back_populates="author")
    favorites: Mapped[list["Favorite"]] = relationship(
        "Favorite", back_populates="user", cascade="all, delete-orphan"
    )
